
package Habitaciones;

public class HabitacionSuiteVistaMar extends Habitaciones{
    
    public int ContadorSuiteVistaMar = 2;
    
    public HabitacionSuiteVistaMar() {
        this.setValorHabitacion(600000);
    }
}
