
package Habitaciones;

public class HabitacionSuiteVistaCiudad extends Habitaciones{
    
    public int ContadorSuiteVistaCiudad = 2;
    
    public HabitacionSuiteVistaCiudad() {
        this.setValorHabitacion(520000);
    }
}
