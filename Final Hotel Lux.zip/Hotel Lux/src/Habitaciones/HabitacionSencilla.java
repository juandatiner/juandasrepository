
package Habitaciones;

public class HabitacionSencilla extends Habitaciones{
    
    public int ContadorSencilla = 3;
    
    public HabitacionSencilla() {
        this.setValorHabitacion(200000);
    }
    
    
}
