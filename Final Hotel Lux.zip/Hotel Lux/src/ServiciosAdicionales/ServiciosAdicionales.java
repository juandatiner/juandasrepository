
package ServiciosAdicionales;

public abstract class ServiciosAdicionales {
    
    protected int ValorServicioAdicional;
    
    public int getValorServicioAdicional() {
        return ValorServicioAdicional;
    }

    public void setValorServicioAdicional(int ValorServicioAdicional) {
        this.ValorServicioAdicional = ValorServicioAdicional;
    }
    
    public ServiciosAdicionales(){
        
    }
}
