
package ServiciosAdicionales;

public class GYM extends ServiciosAdicionales{

    public int ContadorGYM = 1;
    
    public GYM() {
        this.setValorServicioAdicional(15000);
    }
}
