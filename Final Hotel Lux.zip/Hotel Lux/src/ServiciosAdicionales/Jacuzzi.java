
package ServiciosAdicionales;

public class Jacuzzi extends ServiciosAdicionales{
    
    public int ContadorJacuzzi = 1;
    
    public Jacuzzi() {
        this.setValorServicioAdicional(25000);
    }
}
