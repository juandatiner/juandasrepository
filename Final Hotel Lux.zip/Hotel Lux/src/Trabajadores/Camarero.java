
package Trabajadores;

import Datos.Administrativo;

public class Camarero extends Administrativo {
    
}
