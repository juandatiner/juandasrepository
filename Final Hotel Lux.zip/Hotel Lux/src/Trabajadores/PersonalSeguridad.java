
package Trabajadores;

import Datos.Administrativo;

public class PersonalSeguridad extends Administrativo{
    
}
