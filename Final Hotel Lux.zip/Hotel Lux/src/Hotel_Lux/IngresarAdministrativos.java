
package Hotel_Lux;
import Datos.Administrativo;
public class IngresarAdministrativos extends javax.swing.JInternalFrame {
    
    Administrativo nuevoAdm = new Administrativo();
    
    public IngresarAdministrativos() {
        initComponents();
    }
  
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        TextNombreAdministrativos = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        TextApellidoAdministrativos = new javax.swing.JTextField();
        TextNroIDAdministrativos = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        TextEdadAdministrativos = new javax.swing.JTextField();
        TextHoraIngresoAdministrativos = new javax.swing.JTextField();
        TextHoraSalidaAdministrativos = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        ComboBoxProfesionAdministrativos = new javax.swing.JComboBox<>();
        BotonIngresarAdministrativos = new javax.swing.JButton();
        BotonCancelarAdministrativos = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        ComboBoxSexoAdministrativos = new javax.swing.JComboBox<>();
        TextHorasExtraAdministrativos = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Ingresar Administrativos");

        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jLabel2.setText("Datos requeridos");

        jLabel4.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel4.setText("Nombre");

        TextNombreAdministrativos.setText("Ingrese el nombre");

        jLabel5.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel5.setText("Apellido");

        TextApellidoAdministrativos.setText("Ingrese el apellido");
        TextApellidoAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextApellidoAdministrativosActionPerformed(evt);
            }
        });

        TextNroIDAdministrativos.setText("Ingrese el Nro ID");
        TextNroIDAdministrativos.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        TextNroIDAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextNroIDAdministrativosActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel6.setText("NroID");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/trabajo-en-equipo.png"))); // NOI18N

        jLabel7.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel7.setText("Sexo");

        TextEdadAdministrativos.setText("Ingrese la edad");
        TextEdadAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextEdadAdministrativosActionPerformed(evt);
            }
        });

        TextHoraIngresoAdministrativos.setText("Ingrese hora de ingreso");

        TextHoraSalidaAdministrativos.setText("Ingrese la hora de salida");

        jLabel8.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel8.setText("Hora Ingreso");

        jLabel9.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel9.setText("Hora Salida");

        jLabel10.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel10.setText("Edad");

        ComboBoxProfesionAdministrativos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Boton", "Camarero", "Cocinero", "Masajista", "Personal de Limpieza", "Personal de Seguridad", "Recepcionista" }));
        ComboBoxProfesionAdministrativos.setToolTipText("");
        ComboBoxProfesionAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxProfesionAdministrativosActionPerformed(evt);
            }
        });

        BotonIngresarAdministrativos.setBackground(new java.awt.Color(0, 255, 0));
        BotonIngresarAdministrativos.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        BotonIngresarAdministrativos.setText("Ingresar");
        BotonIngresarAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonIngresarAdministrativosActionPerformed(evt);
            }
        });

        BotonCancelarAdministrativos.setBackground(new java.awt.Color(255, 51, 51));
        BotonCancelarAdministrativos.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        BotonCancelarAdministrativos.setText("Cancelar");
        BotonCancelarAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonCancelarAdministrativosActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel11.setText("Profesión");

        ComboBoxSexoAdministrativos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "M", "F" }));
        ComboBoxSexoAdministrativos.setToolTipText("");
        ComboBoxSexoAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxSexoAdministrativosActionPerformed(evt);
            }
        });

        TextHorasExtraAdministrativos.setEditable(false);
        TextHorasExtraAdministrativos.setText("0");
        TextHorasExtraAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextHorasExtraAdministrativosActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel12.setText("Horas Extra");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel2))
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 457, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel4)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING))
                                        .addGap(57, 57, 57)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(TextEdadAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(ComboBoxProfesionAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(ComboBoxSexoAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(TextApellidoAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(TextNombreAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(TextNroIDAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel8)
                                            .addComponent(jLabel9)
                                            .addComponent(jLabel12))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(TextHoraIngresoAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(TextHoraSalidaAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(TextHorasExtraAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(159, 159, 159)
                        .addComponent(BotonIngresarAdministrativos)
                        .addGap(82, 82, 82)
                        .addComponent(BotonCancelarAdministrativos)))
                .addContainerGap(68, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel3))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2)
                        .addGap(19, 19, 19)))
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(TextNroIDAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(TextNombreAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(TextApellidoAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(ComboBoxSexoAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextEdadAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(ComboBoxProfesionAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextHoraIngresoAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextHoraSalidaAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextHorasExtraAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BotonIngresarAdministrativos)
                    .addComponent(BotonCancelarAdministrativos))
                .addGap(24, 24, 24))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ComboBoxProfesionAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxProfesionAdministrativosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxProfesionAdministrativosActionPerformed

    private void TextEdadAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextEdadAdministrativosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextEdadAdministrativosActionPerformed

    private void TextNroIDAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextNroIDAdministrativosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextNroIDAdministrativosActionPerformed

    private void ComboBoxSexoAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxSexoAdministrativosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxSexoAdministrativosActionPerformed

    private void TextApellidoAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextApellidoAdministrativosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextApellidoAdministrativosActionPerformed

    private void BotonIngresarAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonIngresarAdministrativosActionPerformed
    
        int NroIdboton = Integer.parseInt(TextNroIDAdministrativos.getText());
        String Nombreboton = TextNombreAdministrativos.getText();
        String Apellidoboton = TextApellidoAdministrativos.getText();
        String Sexoboton = ComboBoxSexoAdministrativos.getSelectedItem().toString();
        int Edadboton = Integer.parseInt(TextEdadAdministrativos.getText());
        String Profesionboton = ComboBoxProfesionAdministrativos.getSelectedItem().toString();
        int HoraIngresoboton = Integer.parseInt(TextHoraIngresoAdministrativos.getText());
        int HoraSalidaboton = Integer.parseInt(TextHoraSalidaAdministrativos.getText());
        int HorasExtraboton = Integer.parseInt(TextHorasExtraAdministrativos.getText());
        
        nuevoAdm.Recibirdatos(NroIdboton, Nombreboton, Apellidoboton, Sexoboton, Edadboton, Profesionboton, HoraIngresoboton, HoraSalidaboton, HorasExtraboton);
        
        
        TextNroIDAdministrativos.setText("");
        TextNombreAdministrativos.setText("");
        TextApellidoAdministrativos.setText("");
        TextEdadAdministrativos.setText("");
        TextHoraIngresoAdministrativos.setText("");
        TextHoraSalidaAdministrativos.setText("");
        TextNroIDAdministrativos.requestFocus();
    }//GEN-LAST:event_BotonIngresarAdministrativosActionPerformed

    private void TextHorasExtraAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextHorasExtraAdministrativosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextHorasExtraAdministrativosActionPerformed

    private void BotonCancelarAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonCancelarAdministrativosActionPerformed
        
        TextNroIDAdministrativos.setText("");
        TextNombreAdministrativos.setText("");
        TextApellidoAdministrativos.setText("");
        TextEdadAdministrativos.setText("");
        TextHoraIngresoAdministrativos.setText("");
        TextHoraSalidaAdministrativos.setText("");
        TextNroIDAdministrativos.requestFocus();
    }//GEN-LAST:event_BotonCancelarAdministrativosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonCancelarAdministrativos;
    public javax.swing.JButton BotonIngresarAdministrativos;
    private javax.swing.JComboBox<String> ComboBoxProfesionAdministrativos;
    private javax.swing.JComboBox<String> ComboBoxSexoAdministrativos;
    private javax.swing.JTextField TextApellidoAdministrativos;
    private javax.swing.JTextField TextEdadAdministrativos;
    private javax.swing.JTextField TextHoraIngresoAdministrativos;
    private javax.swing.JTextField TextHoraSalidaAdministrativos;
    private javax.swing.JTextField TextHorasExtraAdministrativos;
    private javax.swing.JTextField TextNombreAdministrativos;
    private javax.swing.JTextField TextNroIDAdministrativos;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
