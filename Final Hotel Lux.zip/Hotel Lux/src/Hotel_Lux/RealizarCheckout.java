
package Hotel_Lux;

import Datos.Huespedes;
import Funcionamiento.Checkout;
import Funcionamiento.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Habitaciones.Habitaciones;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class RealizarCheckout extends javax.swing.JInternalFrame {
    
    Conexion enlace = new Conexion();
    Connection connect = enlace.conectar();
    Checkout realizarout = new Checkout();
    Habitaciones cambiar = new Habitaciones();
    Huespedes eliminar = new Huespedes();
    
    
    public RealizarCheckout() {
        initComponents();
        mostrartabla();
    }
    
    
    public void mostrartabla(){
        DefaultTableModel THabitaciones = new DefaultTableModel();
        THabitaciones.addColumn("TIPO");
        THabitaciones.addColumn("NUMERO");
        THabitaciones.addColumn("VALOR");
        THabitaciones.addColumn("DISPONIBILIDAD");
        TablaHabitaciones.setModel(THabitaciones);
        
        String [] datos = new String [4];
        realizarout.Mostrardatos(datos, THabitaciones);
        TablaHabitaciones.setModel(THabitaciones); 
    }
    
    public void revisarhabitacion(String NumeroHabitacion){
        DefaultTableModel THabitaciones = new DefaultTableModel();
        THabitaciones.addColumn("TIPO");
        THabitaciones.addColumn("NUMERO");
        THabitaciones.addColumn("VALOR");
        THabitaciones.addColumn("DISPONIBILIDAD");
        TablaHabitaciones.setModel(THabitaciones);
        
        String [] datos = new String [4];
        TablaHabitaciones.setModel(THabitaciones); 
        realizarout.Disponibilidad(datos, THabitaciones, NumeroHabitacion);
        
    }
    

    public void mostrarvalores(int valornumero,int total){
    
        try {
            PreparedStatement mostrar = connect.prepareStatement("SELECT * FROM habitaciones WHERE Numero="+valornumero);
            mostrar.setInt(1, 1);
            
            ResultSet resultado = null;
            int precio = resultado.getInt("Valor");
            
            PreparedStatement mostrar2 = connect.prepareStatement("SELECT * FROM huespedes WHERE Numero="+valornumero);
            mostrar2.setInt(1, 1);
            
            ResultSet resultado2 = null;
            int dias = resultado2.getInt("Dias");
            
            
            total = precio*dias;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e + " Error en la consulta");
        }
        
    
    }
    
    public void mostrartablafinal (){
        
        DefaultTableModel THabitaciones = new DefaultTableModel();
        THabitaciones.addColumn("TIPO");
        THabitaciones.addColumn("NUMERO");
        THabitaciones.addColumn("VALOR");
        THabitaciones.addColumn("DISPONIBILIDAD");
        TablaHabitaciones.setModel(THabitaciones);
        
        String [] datos = new String [4];
        TablaHabitaciones.setModel(THabitaciones); 
        realizarout.Mostrardatos(datos, THabitaciones);
        
        
    }
            
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        BotonBuscarHuespedes = new javax.swing.JButton();
        TextNumeroHabitacion = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        BotonAceptarHuespedes = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaHabitaciones = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        BotonPagarHuespedes = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        TextPrecio = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        TextDias = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        TextTotal = new javax.swing.JTextField();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Check-in");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Seleccione", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial Black", 1, 14))); // NOI18N
        jPanel1.setToolTipText("");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/huespedes.png"))); // NOI18N

        jLabel5.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        jLabel5.setText("Nro de Habitación");

        BotonBuscarHuespedes.setBackground(new java.awt.Color(255, 255, 51));
        BotonBuscarHuespedes.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        BotonBuscarHuespedes.setText("Buscar");
        BotonBuscarHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonBuscarHuespedesActionPerformed(evt);
            }
        });

        TextNumeroHabitacion.setText("Ingresa el Nro de Habitacion");
        TextNumeroHabitacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextNumeroHabitacionActionPerformed(evt);
            }
        });

        jLabel7.setText("1.");

        BotonAceptarHuespedes.setBackground(new java.awt.Color(0, 255, 0));
        BotonAceptarHuespedes.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        BotonAceptarHuespedes.setText("Aceptar");
        BotonAceptarHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonAceptarHuespedesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(34, 34, 34)
                        .addComponent(TextNumeroHabitacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(BotonBuscarHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(161, 161, 161)
                        .addComponent(BotonAceptarHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(BotonBuscarHuespedes)
                            .addComponent(jLabel7)
                            .addComponent(TextNumeroHabitacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(BotonAceptarHuespedes))
                    .addComponent(jLabel4))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TablaHabitaciones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(TablaHabitaciones);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Pagar", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial Black", 1, 14))); // NOI18N

        BotonPagarHuespedes.setBackground(new java.awt.Color(0, 255, 0));
        BotonPagarHuespedes.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        BotonPagarHuespedes.setText("Pagar");
        BotonPagarHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonPagarHuespedesActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel1.setText("Precio:");

        TextPrecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextPrecioActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel2.setText("Dias:");

        TextDias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextDiasActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel3.setText("Total:");

        TextTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextTotalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(TextPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(TextDias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(TextTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(BotonPagarHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BotonPagarHuespedes)
                    .addComponent(jLabel1)
                    .addComponent(TextPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(TextDias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(TextTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(43, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 12, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BotonBuscarHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonBuscarHuespedesActionPerformed
        
        String NumeroHabitacion= TextNumeroHabitacion.getText();
        revisarhabitacion(NumeroHabitacion);

    }//GEN-LAST:event_BotonBuscarHuespedesActionPerformed

    private void TextNumeroHabitacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextNumeroHabitacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextNumeroHabitacionActionPerformed

    private void BotonPagarHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonPagarHuespedesActionPerformed
        
        int fila = TablaHabitaciones.getSelectedRow();
        String valorn = TablaHabitaciones.getValueAt(fila, 1).toString();
        cambiar.Editarestado(valorn, "1");
        eliminar.Eliminardatosporcheckout(valorn);
        mostrartablafinal();
        

    }//GEN-LAST:event_BotonPagarHuespedesActionPerformed

    private void BotonAceptarHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonAceptarHuespedesActionPerformed
        
//        int precio= 0;
//        int dias = 0;
//        int total = 0;
//        String totaltotal= String.valueOf(total);
//        
//        int fila = TablaHabitaciones.getSelectedRow();
//        String valor = TablaHabitaciones.getValueAt(fila, 1).toString();
//        int valornumero = Integer.parseInt(valor);
//        
//        mostrarvalores(valornumero, total);
//        
//        String precioprecio= String.valueOf(precio);
//        String diasdias= String.valueOf(dias);
//        
//        TextPrecio.setText(precioprecio);
//        TextDias.setText(diasdias);
//        TextTotal.setText(totaltotal);
        
        
        
    }//GEN-LAST:event_BotonAceptarHuespedesActionPerformed

    private void TextPrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextPrecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextPrecioActionPerformed

    private void TextDiasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextDiasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextDiasActionPerformed

    private void TextTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextTotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextTotalActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton BotonAceptarHuespedes;
    public javax.swing.JButton BotonBuscarHuespedes;
    public javax.swing.JButton BotonPagarHuespedes;
    public static javax.swing.JTable TablaHabitaciones;
    private javax.swing.JTextField TextDias;
    public static javax.swing.JTextField TextNumeroHabitacion;
    private javax.swing.JTextField TextPrecio;
    private javax.swing.JTextField TextTotal;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
