package Hotel_Lux;
import Funcionamiento.Conexion;
import Imagenes.ImagenEscritorio;
import javax.swing.ImageIcon;
import java.sql.Connection;
import javax.swing.JOptionPane;

public final class Inicio extends javax.swing.JFrame {

    Conexion enlace = new Conexion();
    Connection connect = enlace.conectar();
    
    public Inicio() {
        initComponents();
        Escritorio.setBorder(new ImagenEscritorio());
        this.setExtendedState(Inicio.MAXIMIZED_BOTH);
        probarconexion();
        
    }
   
    public void probarconexion (){
        if(connect == null){
            Object enunciado = "No se logró la conexión";
            JOptionPane.showMessageDialog(null, enunciado, "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
        }else{
            Object enunciado = "Conexion con exitó";
            JOptionPane.showMessageDialog(null, enunciado);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Escritorio = new javax.swing.JDesktopPane();
        ButtonCheckin = new javax.swing.JButton();
        ButtonCheckout = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        BarAdministrativos = new javax.swing.JMenu();
        ItemIngresarAdministrativos = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        ItemEditarAdministrativos = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        ItemEliminarAdministrativos = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        ItemConsultarAdministrativos = new javax.swing.JMenuItem();
        BarHabitaciones = new javax.swing.JMenu();
        ItemEditarHabitaciones = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JPopupMenu.Separator();
        ItemConsultarHabitaciones = new javax.swing.JMenuItem();
        BarHuespedes = new javax.swing.JMenu();
        ItemEditarHuespedes = new javax.swing.JMenuItem();
        jSeparator6 = new javax.swing.JPopupMenu.Separator();
        ItemConsultarHuespedes = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        ItemEvaluarConexion = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/Lux Imagen.png")).getImage());

        ButtonCheckin.setText("Check-in");
        ButtonCheckin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonCheckinActionPerformed(evt);
            }
        });

        ButtonCheckout.setText("Check-out");
        ButtonCheckout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonCheckoutActionPerformed(evt);
            }
        });

        Escritorio.setLayer(ButtonCheckin, javax.swing.JLayeredPane.DEFAULT_LAYER);
        Escritorio.setLayer(ButtonCheckout, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout EscritorioLayout = new javax.swing.GroupLayout(Escritorio);
        Escritorio.setLayout(EscritorioLayout);
        EscritorioLayout.setHorizontalGroup(
            EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EscritorioLayout.createSequentialGroup()
                .addGap(505, 505, 505)
                .addComponent(ButtonCheckin)
                .addGap(58, 58, 58)
                .addComponent(ButtonCheckout)
                .addContainerGap(401, Short.MAX_VALUE))
        );
        EscritorioLayout.setVerticalGroup(
            EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EscritorioLayout.createSequentialGroup()
                .addContainerGap(437, Short.MAX_VALUE)
                .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ButtonCheckin)
                    .addComponent(ButtonCheckout))
                .addGap(264, 264, 264))
        );

        BarAdministrativos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/trabajo-en-equipo (1).png"))); // NOI18N
        BarAdministrativos.setText("Administrativos");

        ItemIngresarAdministrativos.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        ItemIngresarAdministrativos.setText("Ingresar");
        ItemIngresarAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemIngresarAdministrativosActionPerformed(evt);
            }
        });
        BarAdministrativos.add(ItemIngresarAdministrativos);
        BarAdministrativos.add(jSeparator1);

        ItemEditarAdministrativos.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        ItemEditarAdministrativos.setText("Editar");
        ItemEditarAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemEditarAdministrativosActionPerformed(evt);
            }
        });
        BarAdministrativos.add(ItemEditarAdministrativos);
        BarAdministrativos.add(jSeparator2);

        ItemEliminarAdministrativos.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        ItemEliminarAdministrativos.setText("Eliminar");
        ItemEliminarAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemEliminarAdministrativosActionPerformed(evt);
            }
        });
        BarAdministrativos.add(ItemEliminarAdministrativos);
        BarAdministrativos.add(jSeparator3);

        ItemConsultarAdministrativos.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        ItemConsultarAdministrativos.setText("Consultar");
        ItemConsultarAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemConsultarAdministrativosActionPerformed(evt);
            }
        });
        BarAdministrativos.add(ItemConsultarAdministrativos);

        jMenuBar1.add(BarAdministrativos);

        BarHabitaciones.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/pasillo (1).png"))); // NOI18N
        BarHabitaciones.setText("Habitaciones");

        ItemEditarHabitaciones.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        ItemEditarHabitaciones.setText("Editar");
        ItemEditarHabitaciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemEditarHabitacionesActionPerformed(evt);
            }
        });
        BarHabitaciones.add(ItemEditarHabitaciones);
        BarHabitaciones.add(jSeparator4);

        ItemConsultarHabitaciones.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        ItemConsultarHabitaciones.setText("Consultar");
        ItemConsultarHabitaciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemConsultarHabitacionesActionPerformed(evt);
            }
        });
        BarHabitaciones.add(ItemConsultarHabitaciones);

        jMenuBar1.add(BarHabitaciones);

        BarHuespedes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/huespedes (1).png"))); // NOI18N
        BarHuespedes.setText("Huespedes");

        ItemEditarHuespedes.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.ALT_DOWN_MASK));
        ItemEditarHuespedes.setText("Editar");
        ItemEditarHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemEditarHuespedesActionPerformed(evt);
            }
        });
        BarHuespedes.add(ItemEditarHuespedes);
        BarHuespedes.add(jSeparator6);

        ItemConsultarHuespedes.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.ALT_DOWN_MASK));
        ItemConsultarHuespedes.setText("Consultar");
        ItemConsultarHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemConsultarHuespedesActionPerformed(evt);
            }
        });
        BarHuespedes.add(ItemConsultarHuespedes);

        jMenuBar1.add(BarHuespedes);

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/reparar.png"))); // NOI18N
        jMenu1.setText("Ayuda");

        ItemEvaluarConexion.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.ALT_DOWN_MASK | java.awt.event.InputEvent.CTRL_DOWN_MASK));
        ItemEvaluarConexion.setText("Evaluar Conexion");
        ItemEvaluarConexion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ItemEvaluarConexionActionPerformed(evt);
            }
        });
        jMenu1.add(ItemEvaluarConexion);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Escritorio)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Escritorio)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ItemIngresarAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemIngresarAdministrativosActionPerformed
        IngresarAdministrativos verventana = new IngresarAdministrativos();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_ItemIngresarAdministrativosActionPerformed

    private void ItemEliminarAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemEliminarAdministrativosActionPerformed
        EliminarAdministrativos verventana = new EliminarAdministrativos();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_ItemEliminarAdministrativosActionPerformed

    private void ItemEditarHabitacionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemEditarHabitacionesActionPerformed
        EditarHabitaciones verventana = new EditarHabitaciones();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_ItemEditarHabitacionesActionPerformed

    private void ItemConsultarHabitacionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemConsultarHabitacionesActionPerformed
        ConsultarHabitaciones verventana = new ConsultarHabitaciones();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_ItemConsultarHabitacionesActionPerformed

    private void ItemEditarHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemEditarHuespedesActionPerformed
        EditarHuespedes verventana = new EditarHuespedes();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_ItemEditarHuespedesActionPerformed

    private void ItemEditarAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemEditarAdministrativosActionPerformed
        EditarAdministrativos verventana = new EditarAdministrativos();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_ItemEditarAdministrativosActionPerformed

    private void ItemConsultarAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemConsultarAdministrativosActionPerformed
        ConsultarAdministrativos verventana = new ConsultarAdministrativos();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_ItemConsultarAdministrativosActionPerformed

    private void ItemConsultarHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemConsultarHuespedesActionPerformed
        ConsultarHuespedes verventana = new ConsultarHuespedes();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_ItemConsultarHuespedesActionPerformed

    private void ItemEvaluarConexionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ItemEvaluarConexionActionPerformed
        probarconexion();
    }//GEN-LAST:event_ItemEvaluarConexionActionPerformed

    private void ButtonCheckinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonCheckinActionPerformed
        RealizarCheckin verventana = new RealizarCheckin();
        Escritorio.add(verventana);
        verventana.show();
        
    }//GEN-LAST:event_ButtonCheckinActionPerformed

    private void ButtonCheckoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonCheckoutActionPerformed
        RealizarCheckout verventana = new RealizarCheckout();
        Escritorio.add(verventana);
        verventana.show();
    }//GEN-LAST:event_ButtonCheckoutActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new RunnableImpl());
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu BarAdministrativos;
    private javax.swing.JMenu BarHabitaciones;
    private javax.swing.JMenu BarHuespedes;
    private javax.swing.JButton ButtonCheckin;
    private javax.swing.JButton ButtonCheckout;
    public static javax.swing.JDesktopPane Escritorio;
    private javax.swing.JMenuItem ItemConsultarAdministrativos;
    private javax.swing.JMenuItem ItemConsultarHabitaciones;
    private javax.swing.JMenuItem ItemConsultarHuespedes;
    private javax.swing.JMenuItem ItemEditarAdministrativos;
    private javax.swing.JMenuItem ItemEditarHabitaciones;
    private javax.swing.JMenuItem ItemEditarHuespedes;
    private javax.swing.JMenuItem ItemEliminarAdministrativos;
    private javax.swing.JMenuItem ItemEvaluarConexion;
    private javax.swing.JMenuItem ItemIngresarAdministrativos;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JPopupMenu.Separator jSeparator4;
    private javax.swing.JPopupMenu.Separator jSeparator6;
    // End of variables declaration//GEN-END:variables

    private static class RunnableImpl implements Runnable {

        public RunnableImpl() {
        }

        @Override
        public void run() {
            new Inicio().setVisible(true);
        }
    }
}
