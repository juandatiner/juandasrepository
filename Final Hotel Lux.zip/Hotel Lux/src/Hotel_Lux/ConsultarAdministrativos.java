
package Hotel_Lux;

import Datos.Administrativo;
import javax.swing.table.DefaultTableModel;

public final class ConsultarAdministrativos extends javax.swing.JInternalFrame {

    Administrativo mostrarAdm = new Administrativo();
    
    
    public ConsultarAdministrativos() {
        initComponents();
        mostrartabla(0,null);
    }
    
    public void mostrartabla( int opcionbuscar, String valorbuscar){
        
        
        DefaultTableModel TAdministrativos = new DefaultTableModel();
        TAdministrativos.addColumn("NroID");
        TAdministrativos.addColumn("NOMBRE");
        TAdministrativos.addColumn("APELLIDO");
        TAdministrativos.addColumn("SEXO");
        TAdministrativos.addColumn("EDAD");
        TAdministrativos.addColumn("PROFESION");
        TAdministrativos.addColumn("HORA INGRESO");
        TAdministrativos.addColumn("HORA SALIDA");
        TAdministrativos.addColumn("HORAS EXTRA");
        TablaAdministrativos.setModel(TAdministrativos);

        String [] datos = new String[9];
        mostrarAdm.Mostrardatos(datos, TAdministrativos, opcionbuscar, valorbuscar);
        TablaAdministrativos.setModel(TAdministrativos);
        }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TablaAdministrativos = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        ComboBoxBusquedaAdministrativos = new javax.swing.JComboBox<>();
        ButtonBusquedaAdministrativos = new javax.swing.JButton();
        TextBusquedaAdministrativos = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Consultar Administrativos");

        TablaAdministrativos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(TablaAdministrativos);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Buscar por:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial Black", 1, 14))); // NOI18N

        ComboBoxBusquedaAdministrativos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mostrar todos", "NroID", "Apellido", "Sexo", "Profesión", " " }));
        ComboBoxBusquedaAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxBusquedaAdministrativosActionPerformed(evt);
            }
        });

        ButtonBusquedaAdministrativos.setBackground(new java.awt.Color(0, 255, 0));
        ButtonBusquedaAdministrativos.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        ButtonBusquedaAdministrativos.setText("Buscar");
        ButtonBusquedaAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonBusquedaAdministrativosActionPerformed(evt);
            }
        });

        TextBusquedaAdministrativos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextBusquedaAdministrativosActionPerformed(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/trabajo-en-equipo.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ComboBoxBusquedaAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(TextBusquedaAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52)
                .addComponent(ButtonBusquedaAdministrativos)
                .addContainerGap(143, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ComboBoxBusquedaAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextBusquedaAdministrativos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ButtonBusquedaAdministrativos)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 676, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ComboBoxBusquedaAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxBusquedaAdministrativosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxBusquedaAdministrativosActionPerformed

    private void ButtonBusquedaAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonBusquedaAdministrativosActionPerformed
        int opcionbuscar = ComboBoxBusquedaAdministrativos.getSelectedIndex();
        String valorbuscar = TextBusquedaAdministrativos.getText();
        mostrartabla(opcionbuscar,valorbuscar);
    }//GEN-LAST:event_ButtonBusquedaAdministrativosActionPerformed

    private void TextBusquedaAdministrativosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextBusquedaAdministrativosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextBusquedaAdministrativosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonBusquedaAdministrativos;
    private javax.swing.JComboBox<String> ComboBoxBusquedaAdministrativos;
    private javax.swing.JTable TablaAdministrativos;
    private javax.swing.JTextField TextBusquedaAdministrativos;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
