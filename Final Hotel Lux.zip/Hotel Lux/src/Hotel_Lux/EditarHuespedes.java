
package Hotel_Lux;

import Datos.Huespedes;
import javax.swing.table.DefaultTableModel;

public final class EditarHuespedes extends javax.swing.JInternalFrame {

    Huespedes mostrarHues = new Huespedes();
    Huespedes editarHues = new Huespedes();
    
    public EditarHuespedes() {
        initComponents();
        mostrartabla(0,null);
    }
    
    public void mostrartabla( int opcionbuscar, String valorbuscar){
        
        
        DefaultTableModel THuespedes = new DefaultTableModel();
        THuespedes.addColumn("NroID");
        THuespedes.addColumn("NOMBRE");
        THuespedes.addColumn("APELLIDO");
        THuespedes.addColumn("SEXO");
        THuespedes.addColumn("EDAD");
        THuespedes.addColumn("HABITACION");
        THuespedes.addColumn("CORREO TITULAR");
        THuespedes.addColumn("DIAS");
        TablaHuespedes.setModel(THuespedes);

        String [] datos = new String[8];
        mostrarHues.Mostrardatos(datos, THuespedes, opcionbuscar, valorbuscar);
        TablaHuespedes.setModel(THuespedes);
        
    }
    
    public void actualizardatos(int id, String nombre, String apellido, String sexo, int edad, String correotitular){
        
        editarHues.Editardatos(id, nombre, apellido, sexo, edad, correotitular);

    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TablaHuespedes = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        ComboBoxBusquedaHuespedes = new javax.swing.JComboBox<>();
        ButtonBusquedaHuespedes = new javax.swing.JButton();
        TextBusquedaHuespedes = new javax.swing.JTextField();
        ButtonActualizarHuespedes = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Editar Huespedes");

        TablaHuespedes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(TablaHuespedes);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Buscar por:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial Black", 1, 14))); // NOI18N

        ComboBoxBusquedaHuespedes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mostrar todos", "NroID", "Apellido", "Sexo", "Habitacion", " " }));
        ComboBoxBusquedaHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxBusquedaHuespedesActionPerformed(evt);
            }
        });

        ButtonBusquedaHuespedes.setBackground(new java.awt.Color(0, 255, 0));
        ButtonBusquedaHuespedes.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        ButtonBusquedaHuespedes.setText("Buscar");
        ButtonBusquedaHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonBusquedaHuespedesActionPerformed(evt);
            }
        });

        TextBusquedaHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextBusquedaHuespedesActionPerformed(evt);
            }
        });

        ButtonActualizarHuespedes.setBackground(new java.awt.Color(255, 255, 51));
        ButtonActualizarHuespedes.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        ButtonActualizarHuespedes.setText("Actualizar");
        ButtonActualizarHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonActualizarHuespedesActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        jLabel1.setText("Los NroID- NroHabitacion- NroDias no pueden ser editados.");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/huespedes.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(ComboBoxBusquedaHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(TextBusquedaHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(ButtonBusquedaHuespedes)
                        .addGap(26, 26, 26)
                        .addComponent(ButtonActualizarHuespedes))
                    .addComponent(jLabel1))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ComboBoxBusquedaHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextBusquedaHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ButtonBusquedaHuespedes)
                            .addComponent(ButtonActualizarHuespedes))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 428, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ComboBoxBusquedaHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxBusquedaHuespedesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxBusquedaHuespedesActionPerformed

    private void ButtonBusquedaHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonBusquedaHuespedesActionPerformed
        int opcionbuscar = ComboBoxBusquedaHuespedes.getSelectedIndex();
        String valorbuscar = TextBusquedaHuespedes.getText();
        mostrartabla(opcionbuscar,valorbuscar);
    }//GEN-LAST:event_ButtonBusquedaHuespedesActionPerformed

    private void TextBusquedaHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextBusquedaHuespedesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextBusquedaHuespedesActionPerformed

    private void ButtonActualizarHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonActualizarHuespedesActionPerformed
        
        int fila = TablaHuespedes.getSelectedRow();
        
        int id = Integer.parseInt(this.TablaHuespedes.getValueAt(fila, 0).toString());
        String nombre = TablaHuespedes.getValueAt(fila, 1).toString();
        String apellido = TablaHuespedes.getValueAt(fila, 2).toString();
        String sexo = TablaHuespedes.getValueAt(fila, 3).toString();
        int edad = Integer.parseInt(this.TablaHuespedes.getValueAt(fila, 4).toString());
        String correotitular = TablaHuespedes.getValueAt(fila, 6).toString();
        
        
        actualizardatos(id, nombre, apellido, sexo, edad, correotitular);
        
    }//GEN-LAST:event_ButtonActualizarHuespedesActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonActualizarHuespedes;
    private javax.swing.JButton ButtonBusquedaHuespedes;
    private javax.swing.JComboBox<String> ComboBoxBusquedaHuespedes;
    private javax.swing.JTable TablaHuespedes;
    private javax.swing.JTextField TextBusquedaHuespedes;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
