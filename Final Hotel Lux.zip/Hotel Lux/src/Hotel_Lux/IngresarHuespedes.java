
package Hotel_Lux;
import Datos.Huespedes;
import Habitaciones.Habitaciones;
public class IngresarHuespedes extends javax.swing.JInternalFrame {
    
    Huespedes nuevoHuesped = new Huespedes();
    Habitaciones cambiar = new Habitaciones();
     
    public IngresarHuespedes() {
        initComponents();
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        TextNombreHuespedes = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        TextApellidoHuespedes = new javax.swing.JTextField();
        TextNroIDHuespedes = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        TextCorreoHuespedes = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        BotonIngresarHuespedes = new javax.swing.JButton();
        BotonCancelarHuespedes = new javax.swing.JButton();
        ComboBoxSexoHuespedes = new javax.swing.JComboBox<>();
        TextEdadHuespedes = new javax.swing.JTextField();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Ingresar Huespedes");

        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jLabel2.setText("Datos requeridos");

        jLabel4.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel4.setText("Nombre");

        TextNombreHuespedes.setText("Ingrese el nombre");

        jLabel5.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel5.setText("Apellido");

        TextApellidoHuespedes.setText("Ingrese el apellido");
        TextApellidoHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextApellidoHuespedesActionPerformed(evt);
            }
        });

        TextNroIDHuespedes.setText("Ingrese el Nro ID");
        TextNroIDHuespedes.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        TextNroIDHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextNroIDHuespedesActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel6.setText("NroID");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/huespedes.png"))); // NOI18N

        jLabel7.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel7.setText("Sexo");

        TextCorreoHuespedes.setText("Ingrese Correo del titular");
        TextCorreoHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextCorreoHuespedesActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel8.setText("Correo T.");

        jLabel10.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel10.setText("Edad");

        BotonIngresarHuespedes.setBackground(new java.awt.Color(0, 255, 0));
        BotonIngresarHuespedes.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        BotonIngresarHuespedes.setText("Ingresar");
        BotonIngresarHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonIngresarHuespedesActionPerformed(evt);
            }
        });

        BotonCancelarHuespedes.setBackground(new java.awt.Color(255, 51, 51));
        BotonCancelarHuespedes.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        BotonCancelarHuespedes.setText("Cancelar");
        BotonCancelarHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonCancelarHuespedesActionPerformed(evt);
            }
        });

        ComboBoxSexoHuespedes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "M", "F" }));
        ComboBoxSexoHuespedes.setToolTipText("");
        ComboBoxSexoHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxSexoHuespedesActionPerformed(evt);
            }
        });

        TextEdadHuespedes.setText("Ingrese la edad");
        TextEdadHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextEdadHuespedesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel2))
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 457, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel4)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel7)
                                            .addComponent(jLabel10)
                                            .addComponent(jLabel8))
                                        .addGap(50, 50, 50)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(TextCorreoHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(ComboBoxSexoHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(TextApellidoHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(TextNombreHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(TextNroIDHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(TextEdadHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(159, 159, 159)
                        .addComponent(BotonIngresarHuespedes)
                        .addGap(79, 79, 79)
                        .addComponent(BotonCancelarHuespedes)))
                .addContainerGap(90, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel3))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2)
                        .addGap(19, 19, 19)))
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(TextNroIDHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(TextNombreHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(TextApellidoHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(ComboBoxSexoHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(TextEdadHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(TextCorreoHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BotonIngresarHuespedes)
                    .addComponent(BotonCancelarHuespedes))
                .addContainerGap(128, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TextNroIDHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextNroIDHuespedesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextNroIDHuespedesActionPerformed

    private void ComboBoxSexoHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxSexoHuespedesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxSexoHuespedesActionPerformed

    private void TextApellidoHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextApellidoHuespedesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextApellidoHuespedesActionPerformed

    private void BotonIngresarHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonIngresarHuespedesActionPerformed
    
        
        int NroIdboton = Integer.parseInt(TextNroIDHuespedes.getText());
        String Nombreboton = TextNombreHuespedes.getText();
        String Apellidoboton = TextApellidoHuespedes.getText();
        String Sexoboton = ComboBoxSexoHuespedes.getSelectedItem().toString();
        int Edadboton = Integer.parseInt(TextEdadHuespedes.getText());
        String Correoboton = TextCorreoHuespedes.getText();
        int NumeroDias = Integer.parseInt(RealizarCheckin.TextDiasHuespedes.getText());
        int fila = RealizarCheckin.TablaHabitaciones.getSelectedRow();
        String valor = RealizarCheckin.TablaHabitaciones.getValueAt(fila, 1).toString();
        
        nuevoHuesped.Recibirdatos(NroIdboton, Nombreboton, Apellidoboton, Sexoboton, Edadboton, Correoboton, NumeroDias, valor);
        cambiar.Editarestado(valor, "0");
        
        
        TextNroIDHuespedes.setText("");
        TextNombreHuespedes.setText("");
        TextApellidoHuespedes.setText("");
        TextEdadHuespedes.setText("");
        TextCorreoHuespedes.setText("");
        TextNroIDHuespedes.requestFocus();
    }//GEN-LAST:event_BotonIngresarHuespedesActionPerformed

    private void BotonCancelarHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonCancelarHuespedesActionPerformed
        
        TextNroIDHuespedes.setText("");
        TextNombreHuespedes.setText("");
        TextApellidoHuespedes.setText("");
        TextEdadHuespedes.setText("");
        TextCorreoHuespedes.setText("");
        TextNroIDHuespedes.requestFocus();
    }//GEN-LAST:event_BotonCancelarHuespedesActionPerformed

    private void TextEdadHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextEdadHuespedesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextEdadHuespedesActionPerformed

    private void TextCorreoHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextCorreoHuespedesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextCorreoHuespedesActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonCancelarHuespedes;
    public javax.swing.JButton BotonIngresarHuespedes;
    private javax.swing.JComboBox<String> ComboBoxSexoHuespedes;
    private javax.swing.JTextField TextApellidoHuespedes;
    private javax.swing.JTextField TextCorreoHuespedes;
    private javax.swing.JTextField TextEdadHuespedes;
    private javax.swing.JTextField TextNombreHuespedes;
    private javax.swing.JTextField TextNroIDHuespedes;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
