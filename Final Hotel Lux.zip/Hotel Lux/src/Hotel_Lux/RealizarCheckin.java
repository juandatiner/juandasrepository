
package Hotel_Lux;
import Funcionamiento.Checkin;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class RealizarCheckin extends javax.swing.JInternalFrame {

    Checkin nuevoHue = new Checkin();
    
    
    public RealizarCheckin() {
        initComponents();
        mostrartabla();
    }
    
    
    public void abrirescritorio(){
    
        IngresarHuespedes ven2 = new IngresarHuespedes();
        Inicio.Escritorio.add(ven2);
        ven2.toFront();
        ven2.setVisible(true);
    }
    
    public void cerrarescritorio(){
    
        IngresarHuespedes ven2 = new IngresarHuespedes();
        Inicio.Escritorio.add(ven2);
        ven2.toFront();
        ven2.setVisible(false);
    }
    
    public void mostrartabla(){
        DefaultTableModel THabitaciones = new DefaultTableModel();
        THabitaciones.addColumn("TIPO");
        THabitaciones.addColumn("NUMERO");
        THabitaciones.addColumn("VALOR");
        THabitaciones.addColumn("DISPONIBILIDAD");
        TablaHabitaciones.setModel(THabitaciones);
        
        String [] datos = new String [4];
        nuevoHue.Mostrardatos(datos, THabitaciones);
        TablaHabitaciones.setModel(THabitaciones); 
    }
    
    public void revisardisponibilidad(int opcionbuscar){
        DefaultTableModel THabitaciones = new DefaultTableModel();
        THabitaciones.addColumn("TIPO");
        THabitaciones.addColumn("NUMERO");
        THabitaciones.addColumn("VALOR");
        THabitaciones.addColumn("DISPONIBILIDAD");
        TablaHabitaciones.setModel(THabitaciones);
        
        String [] datos = new String [4];
        TablaHabitaciones.setModel(THabitaciones); 
        nuevoHue.Disponibilidad(datos, THabitaciones, opcionbuscar);
        
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        ComboBoxTipoHabitacion = new javax.swing.JComboBox<>();
        BotonBuscarHuespedes = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        TextNumeroHuespedes = new javax.swing.JTextField();
        BotonAceptarHuespedes = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        TextDiasHuespedes = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaHabitaciones = new javax.swing.JTable();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Check-in");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Seleccione", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial Black", 1, 14))); // NOI18N
        jPanel1.setToolTipText("");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/huespedes.png"))); // NOI18N

        jLabel5.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        jLabel5.setText("Tipo de Habitación");

        ComboBoxTipoHabitacion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sencilla", "Doble", "Suite Vista Ciudad", "Suite Vista Mar", "Suite Presidencial" }));
        ComboBoxTipoHabitacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxTipoHabitacionActionPerformed(evt);
            }
        });

        BotonBuscarHuespedes.setBackground(new java.awt.Color(255, 255, 51));
        BotonBuscarHuespedes.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        BotonBuscarHuespedes.setText("Buscar");
        BotonBuscarHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonBuscarHuespedesActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        jLabel6.setText("Nro de Huespedes");

        TextNumeroHuespedes.setText("Ingresa el Nro de Huespedes");
        TextNumeroHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextNumeroHuespedesActionPerformed(evt);
            }
        });

        BotonAceptarHuespedes.setBackground(new java.awt.Color(0, 255, 0));
        BotonAceptarHuespedes.setFont(new java.awt.Font("Gill Sans Ultra Bold", 0, 12)); // NOI18N
        BotonAceptarHuespedes.setText("Aceptar");
        BotonAceptarHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonAceptarHuespedesActionPerformed(evt);
            }
        });

        jLabel7.setText("1.");

        jLabel8.setText("2.");

        jLabel9.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        jLabel9.setText("Nro de Días");

        jLabel10.setText("3.");

        TextDiasHuespedes.setText("Ingresa el Nro de Días");
        TextDiasHuespedes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextDiasHuespedesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel9))
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ComboBoxTipoHabitacion, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(TextNumeroHuespedes)
                    .addComponent(TextDiasHuespedes))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(BotonAceptarHuespedes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BotonBuscarHuespedes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(ComboBoxTipoHabitacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BotonBuscarHuespedes)
                            .addComponent(jLabel7))
                        .addGap(23, 23, 23)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(TextNumeroHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8)))
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(TextDiasHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BotonAceptarHuespedes))
                .addContainerGap())
        );

        TablaHabitaciones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(TablaHabitaciones);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 13, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ComboBoxTipoHabitacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxTipoHabitacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxTipoHabitacionActionPerformed

    private void BotonBuscarHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonBuscarHuespedesActionPerformed

        int opcionbuscar = ComboBoxTipoHabitacion.getSelectedIndex();
        revisardisponibilidad(opcionbuscar);

    }//GEN-LAST:event_BotonBuscarHuespedesActionPerformed

    private void TextNumeroHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextNumeroHuespedesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextNumeroHuespedesActionPerformed

    private void BotonAceptarHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonAceptarHuespedesActionPerformed
        
        int NumeroHuespedes = Integer.parseInt(TextNumeroHuespedes.getText());
        int NumeroDias = Integer.parseInt(TextDiasHuespedes.getText());
        
        if (NumeroHuespedes > 4 || NumeroDias < 1){
            JOptionPane.showMessageDialog(null, "Solo se pueden ingresar maximo 4 huespedes por solicitud"+"La cantidad de días minimos es 1");
        }else{
            abrirescritorio();
        }

    }//GEN-LAST:event_BotonAceptarHuespedesActionPerformed

    private void TextDiasHuespedesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextDiasHuespedesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextDiasHuespedesActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton BotonAceptarHuespedes;
    public javax.swing.JButton BotonBuscarHuespedes;
    private javax.swing.JComboBox<String> ComboBoxTipoHabitacion;
    public static javax.swing.JTable TablaHabitaciones;
    public static javax.swing.JTextField TextDiasHuespedes;
    public static javax.swing.JTextField TextNumeroHuespedes;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
