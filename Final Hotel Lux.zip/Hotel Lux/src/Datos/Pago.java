
package Datos;

public class Pago <K>{
    
    public K valor;
    
    Pago <Integer> Numero = new Pago<Integer>();
    Pago <String> Nombre = new Pago<String>();
    Pago <Integer> Clave = new Pago<Integer>();
    Pago <Integer> Cuota = new Pago<Integer>();
    
}
