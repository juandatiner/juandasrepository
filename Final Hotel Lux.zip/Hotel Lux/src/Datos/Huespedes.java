
package Datos;

import Funcionamiento.Conexion;
import java.awt.HeadlessException;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Huespedes extends Persona {
    
    Conexion enlace = new Conexion();
    Connection connect = enlace.conectar();
    
    
    public int habitacion;
    
    public String CorreoTitular;
    
    
    public int getHabitacion() {
        return habitacion;
    }

    public void setHabitacion(int habitacion) {
        this.habitacion = habitacion;
    }

    public String getCorreoTitular() {
        return CorreoTitular;
    }

    public void setCorreoTitular(String CorreoTitular) {
        this.CorreoTitular = CorreoTitular;
    }
    
    public Huespedes(){
        
    }
    
    public void Recibirdatos(int NroIdboton, String Nombreboton, String Apellidoboton, String Sexoboton, int Edadboton, String Correoboton, int NumeroDias, String valor) {
        
        String idCadena= String.valueOf(NroIdboton);
        String edadCadena= String.valueOf(Edadboton);
        String diasCadena= String.valueOf(NumeroDias);
        
        
        try {
            
            
            PreparedStatement guardar = connect.prepareStatement("INSERT INTO huespedes (idHuespedes,Nombre,Apellido,Sexo,Edad,"
                    + "Habitacion,CorreoTitular,Dias) VALUES (?,?,?,?,?,?,?,?)") ;
            guardar.setString(1, idCadena);
            guardar.setString(2, Nombreboton);
            guardar.setString(3, Apellidoboton);
            guardar.setString(4, Sexoboton);
            guardar.setString(5, edadCadena);
            guardar.setString(6, valor);
            guardar.setString(7, Correoboton);
            guardar.setString(8, diasCadena);
            guardar.executeUpdate();
            JOptionPane.showMessageDialog(null, "Huesped Ingresado con exitó");
            
            
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No se logró Ingresar Huesped");
        }
        
    }
    
    
    public void Mostrardatos(String [] datos, DefaultTableModel THuespedes, int opcionbuscar, String valorbuscar){
        
        String codsql;
                
        if(opcionbuscar == 0 && valorbuscar == null){
            codsql = "SELECT * FROM huespedes";
        }else{
            if(opcionbuscar == 1 && valorbuscar != null){
                codsql = "SELECT * FROM huespedes WHERE idHuespedes = '"+ valorbuscar+"'";
            }else{
                if(opcionbuscar == 2 && valorbuscar != null){
                    codsql = "SELECT * FROM huespedes WHERE Apellido = '"+ valorbuscar+"'";  
                }else{
                    if(opcionbuscar == 3 && valorbuscar != null){
                        codsql = "SELECT * FROM huespedes WHERE Sexo = '"+ valorbuscar+"'";
                    }else{
                        if(opcionbuscar == 4 && valorbuscar != null){
                            codsql = "SELECT * FROM huespedes WHERE habitacion = '"+ valorbuscar+"'";
                        }else{
                            codsql = "SELECT * FROM huespedes";
                        }
                    }    
                }
            }
        }        
        
        
        try {
            Statement leer = connect.createStatement();
            ResultSet resultado = leer.executeQuery(codsql);
            
            while (resultado.next()){
                datos [0] = resultado.getString(1);
                datos [1] = resultado.getString(2);
                datos [2] = resultado.getString(3);
                datos [3] = resultado.getString(4);
                datos [4] = resultado.getString(5);
                datos [5] = resultado.getString(6);
                datos [6] = resultado.getString(7);
                datos [7] = resultado.getString(8);
                THuespedes.addRow(datos);
             
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " Error en la consulta");
        }  
    }
    
    public void Editardatos(int id, String nombre, String apellido, String sexo, int edad, String correotitular){
        
        try {
            PreparedStatement actualizar = connect.prepareStatement("UPDATE huespedes SET Nombre='"+nombre+"',Apellido='"+apellido+"'"
                    + ",Sexo='"+sexo+"',Edad='"+edad+"',CorreoTitular='"+correotitular+"'"+"WHERE idHuespedes='"+id+"'");
            actualizar.executeUpdate();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No se logró actualizar los datos");
        }   
    }
    
    public void Eliminardatos(String valor){
        
        try {
            PreparedStatement eliminar = connect.prepareStatement("DELETE FROM huespedes WHERE idHuespedes='"+valor+"'");
            eliminar.executeUpdate();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No se logró eliminar el Huesped");
        }
        
    }
    
    public void Eliminardatosporcheckout(String valorn){
        
        try {
            PreparedStatement eliminar = connect.prepareStatement("DELETE FROM huespedes WHERE Habitacion='"+valorn+"'");
            eliminar.executeUpdate();
            JOptionPane.showMessageDialog(null, "Pago realizado con exitó");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No se logró eliminar el Huesped");
        }

        
        
    }
    
}
