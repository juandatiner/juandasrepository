
package Funcionamiento;

import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Checkout {
    
    Conexion enlace = new Conexion();
    Connection connect = enlace.conectar(); 
    
public void Mostrardatos(String [] datos, DefaultTableModel THabitaciones){
        
    String codsql;
                
    codsql = "SELECT * FROM habitaciones WHERE Disponibilidad='"+"0"+"'";
           
    imprimirdatos(codsql,datos,THabitaciones); 

}    

public void Disponibilidad(String [] datos, DefaultTableModel THabitaciones, String NumeroHabitacion){
        
    String codsql = "SELECT * FROM habitaciones WHERE Numero='"+NumeroHabitacion+"'"+"AND Disponibilidad='"+"0"+"'";
    imprimirdatos(codsql,datos,THabitaciones);
        
               
}



public void imprimirdatos(String codsql, String [] datos, DefaultTableModel THabitaciones){
        
        try {
            Statement leer = connect.createStatement();
            ResultSet resultado = leer.executeQuery(codsql);
            
            while (resultado.next()){
                datos [0] = resultado.getString(1);
                datos [1] = resultado.getString(2);
                datos [2] = resultado.getString(3);
                datos [3] = resultado.getString(4);
                THabitaciones.addRow(datos);
             
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " Error en la consulta");
        }
}



}


    

