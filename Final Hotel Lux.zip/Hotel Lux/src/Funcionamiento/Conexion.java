
package Funcionamiento;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {
    
    Connection enlazar = null;
    
    public Connection conectar(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            enlazar = DriverManager.getConnection("jdbc:mysql://us-east.connect.psdb.cloud/hotellux?sslMode=VERIFY_IDENTITY","1fov0mt85km718xjqd1p","pscale_pw_ruBE0DmKmPqKGVcEfv2px12zOOJr1YU5PguM0qqabgG");
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No fue posible establecer la conexión");
        }
        return enlazar;
    }
    
}
