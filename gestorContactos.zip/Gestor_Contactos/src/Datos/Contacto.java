
package Datos;

import Funcionamiento.Conexion;
import java.awt.HeadlessException;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Contacto extends Persona{
    
    Conexion enlace = new Conexion();
    Connection connect = enlace.conectar();
    
    
    public Contacto(){
    }
    
    public void Recibirdatos(long NroTelefonoboton, String Nombreboton, String Apellidoboton) {
        
        String telefono= String.valueOf(NroTelefonoboton);

        try {
            PreparedStatement guardar = connect.prepareStatement("INSERT INTO contactos (Telefono,Nombre,Apellido) VALUES (?,?,?)") ;
            guardar.setString(1, telefono);
            guardar.setString(2, Nombreboton);
            guardar.setString(3, Apellidoboton);

            guardar.executeUpdate();
            JOptionPane.showMessageDialog(null, "Contacto Ingresado con éxito");
            
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null," No se logró Ingresar Contacto");
        } 

    }
    
    public void Mostrardatos(String [] datos, DefaultTableModel TContactos, int opcionbuscar, String valorbuscar){
        
        String codsql;
                
        if(opcionbuscar == 0 && valorbuscar == null){
            codsql = "SELECT * FROM contactos";
        }else{
            if(opcionbuscar == 1 && valorbuscar != null){
                codsql = "SELECT * FROM contactos WHERE Telefono = '"+ valorbuscar+"'";
            }else{
                if(opcionbuscar == 2 && valorbuscar != null){
                    codsql = "SELECT * FROM contactos WHERE Nombre = '"+ valorbuscar+"'";  
                }else{
                    if(opcionbuscar == 3 && valorbuscar != null){
                        codsql = "SELECT * FROM contactos WHERE Apellido = '"+ valorbuscar+"'";
                    }else{
                        codsql = "SELECT * FROM contactos";
                    }
                }    
            }
        }
                
        
        
        try {
            Statement leer = connect.createStatement();
            ResultSet resultado = leer.executeQuery(codsql);
            
            while (resultado.next()){
                datos [0] = resultado.getString(1);
                datos [1] = resultado.getString(2);
                datos [2] = resultado.getString(3);
                TContactos.addRow(datos);
             
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " Error en la consulta");
        }  
    }
    
    public void Editardatos(int telefono, String nombre, String apellido){
        
        try {
            PreparedStatement actualizar = connect.prepareStatement("UPDATE contactos SET Nombre='"+nombre+"',Apellido='"+apellido+"'"
                    +"WHERE Telefono='"+telefono+"'");
            actualizar.executeUpdate();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No se logró actualizar los datos");
        }   
    }
    
    public void Eliminardatos(String valor){
        
        try {
            PreparedStatement eliminar = connect.prepareStatement("DELETE FROM contactos WHERE telefono='"+valor+"'");
            eliminar.executeUpdate();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No se logró eliminar el Contacto");
        }
        
    }
    
    public void Vaciarlista(){  
        try {
            PreparedStatement vaciar = connect.prepareStatement("DELETE FROM contactos");
            vaciar.executeUpdate();
                    
        }catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No se logró Vaciar");
        }
    
    }
}