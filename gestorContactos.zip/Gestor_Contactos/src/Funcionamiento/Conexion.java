
package Funcionamiento;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {
    
    Connection enlazar = null;
    
    public Connection conectar(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            enlazar = DriverManager.getConnection(
  "jdbc:mysql://aws.connect.psdb.cloud/gestorcontactos?sslMode=VERIFY_IDENTITY",
  "hxw6ndf9wxgyvc25erfy",
  "pscale_pw_gOVlhUa1DiRsbLJFn9sEqyUhNtE915vMhXh1eqa8zAm");
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, e + " No fue posible establecer la conexión");
        }
        return enlazar;
    }
    
}
